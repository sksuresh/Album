//
//  LyricsCell.swift
//  MusicSearch
//
//  Created by SureshDokula on 23/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import UIKit

class LyricsCell : UITableViewCell {
    
    @IBOutlet var lableFieldName:UILabel!
    @IBOutlet var lableFieldValue:UILabel!
    
    
}