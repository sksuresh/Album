//
//  ImageExtenson.swift
//  MusicSearch
//
//  Created by SureshDokula on 23/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import UIKit
import Foundation

extension UIImageView {
    func downloadImageFrom(link link:String, contentMode: UIViewContentMode) {
        NSURLSession.sharedSession().dataTaskWithURL( NSURL(string:link)!, completionHandler: {
            (data, response, error) -> Void in
            dispatch_async(dispatch_get_main_queue()) {
                self.contentMode =  contentMode
                if let data = data { self.image = UIImage(data: data) }
            }
        }).resume()
    }
}