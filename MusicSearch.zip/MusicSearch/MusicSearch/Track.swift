//
//  Track.swift
//  MusicSearch
//
//  Created by SureshDokula on 22/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import Foundation
struct Track {
    let wrapperType:String
    let kind:String
    let artistName:String
    let collectionName:String
    let trackName:String
    let trackViewUrl:String
    let previewUrl:String
    let artworkUrl30:String
    let artworkUrl60:String
    let artworkUrl100:String
    let trackPrice:NSNumber
    let longDescription:String
    let primaryGenreName:String
    
   init(wrappertype:String?,kind:String?,artistName:String?,collectionName:String?,trackName:String?,trackViewUrl:String?,previewUrl:String?,artworkUrl30:String?,artworkUrl60:String?,artworkUrl100:String?,trackPrice:NSNumber,longDescription:String?,primaryGenreName:String?){
        self.wrapperType = wrappertype ?? ""
        self.kind = kind ?? ""
        self.artistName = artistName ?? ""
        self.collectionName = collectionName ?? ""
        self.trackName = trackName ?? ""
        self.trackViewUrl = trackViewUrl ?? ""
        self.previewUrl = previewUrl ?? ""
        self.artworkUrl30 = artworkUrl30 ?? ""
        self.artworkUrl60 = artworkUrl60 ?? ""
        self.artworkUrl100 = artworkUrl100 ?? ""
        self.trackPrice = trackPrice
        self.longDescription = longDescription ?? ""
        self.primaryGenreName = primaryGenreName ?? ""
    }
    
    func dict() -> [String:String]{
        var dictionary:[String:String] = [:]
        dictionary["wrapperType"] = self.wrapperType
        dictionary["kind"] = self.kind
        dictionary["artistName"] = self.artistName
        dictionary["collectionName"] = self.collectionName
        dictionary["trackName"] = self.trackName
        dictionary["trackViewUrl"] = self.trackViewUrl
        dictionary["artworkUrl100"] = self.artworkUrl100
        dictionary["artworkUrl30"] = self.artworkUrl30
        dictionary["artworkUrl60"] = self.artworkUrl60
        dictionary["longDescription"] = self.longDescription
        dictionary["primaryGenreName"] = self.primaryGenreName
        return dictionary
    }
}