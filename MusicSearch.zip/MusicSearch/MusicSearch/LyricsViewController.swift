//
//  LyricsViewController.swift
//  MusicSearch
//
//  Created by SureshDokula on 23/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import UIKit

class LyricsViewController : UIViewController {
    
    @IBOutlet var tableView:UITableView!
    lazy var lyricsViewModel:LyricsViewModel =  { LyricsViewModel(delegate: self) }()

    var sortedKeys: Array<String> = []
    var dict:Dictionary<String, String> = [:] {
        didSet {
            sortedKeys = dict.keys.sort()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.tableView.reloadData()
        lyricsViewModel.getSongForArtist(dict["artistName"], song: dict["trackName"])
    }
    
    
}

extension LyricsViewController: LyricsViewModelState {
    
    func update(state: LyricsServiceStateChange) {
        switch(state){
        case .sucess(let lyric):
              lyric.dict().forEach({ (key,value) -> () in
                self.dict[key] = value
            })
            self.tableView.reloadData()
            print("lyric")
        case .fail(let error):
            print("Error")
        case .initialise:
            print("initialise")
        case .startProcess:
            print("startProcess")
        default: break
        }
    }
}

extension LyricsViewController:UITableViewDataSource {
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sortedKeys.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell    = tableView.dequeueReusableCellWithIdentifier("lyricscell", forIndexPath: indexPath) as! LyricsCell
        let key = sortedKeys[indexPath.row] as String
        let value = dict[key]! as String
        cell.lableFieldName.text  = key
        cell.lableFieldValue.text = value
        return cell
    }
    
}

extension LyricsViewController:UITableViewDelegate {
 
    func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 44.0
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
}