//
//  ViewController.swift
//  MusicSearch
//
//  Created by SureshDokula on 22/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    lazy var albumViewModel:AlbumViewModel =  { AlbumViewModel(delegate: self) }()
    @IBOutlet var tableView:UITableView!
    var selectedTrack:Track!
    var resultsArray:[Track] = [] {
        didSet{
            dispatch_async(dispatch_get_main_queue()) {
            self.tableView.reloadData()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
      let lyrics =  segue.destinationViewController as! LyricsViewController
        lyrics.dict = self.selectedTrack.dict()
    }
}

extension ViewController:UITableViewDataSource {
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.resultsArray.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell    = tableView.dequeueReusableCellWithIdentifier("albumcell", forIndexPath: indexPath) as! AlbumCell
        let track:Track = self.resultsArray[indexPath.row]
        cell.lblAlbumName.text = track.collectionName
        cell.lblArtistName.text = track.artistName
        cell.lblTrackName.text = track.trackName
        cell.albumImageView.downloadImageFrom(link: track.artworkUrl60, contentMode: UIViewContentMode.ScaleAspectFit)

        return cell
    }
}

extension ViewController:UITableViewDelegate{
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.selectedTrack = self.resultsArray[indexPath.row]
        self.performSegueWithIdentifier("lyrics", sender: self)
    }
}

extension ViewController:UISearchBarDelegate {
    
     func searchBarSearchButtonClicked(searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        self.albumViewModel.getAlbumForArtist(searchBar.text)
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
        if searchBar.text?.characters.count == 0 {
            searchBar.resignFirstResponder()
        }
    }
}

extension ViewController:AlbumViewModelState {
    func update(state: StateChange) {
        switch(state){
        case .initialise:
            print("initialisation")
        case .startProcess:
            print("process started")
        case .sucess(let results):
            print("success" + String(results))
            self.resultsArray = results
        case .fail(let error):
            print("failed" + String(error))
        }
    }
}
