//
//  Lyric.swift
//  MusicSearch
//
//  Created by SureshDokula on 22/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import Foundation

struct  Lyric {
    let artist:String
    let song:String
    let lyrics:String
    let url:String
    
    init(artist:String?,song:String?,lyrics:String?,url:String?){
        self.artist = artist ?? ""
        self.song = song ?? ""
        self.lyrics = lyrics ?? ""
        self.url = url ?? ""
    }
    
    func dict() -> [String:String]{
        var dictionary:[String:String] = [:]
        dictionary["artist"] = self.artist
        dictionary["song"] = self.song
        dictionary["lyrics"] = self.lyrics
        dictionary["url"] = self.url
        return dictionary
    }
}