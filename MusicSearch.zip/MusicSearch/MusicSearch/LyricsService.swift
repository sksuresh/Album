//
//  LyricsService.swift
//  MusicSearch
//
//  Created by SureshDokula on 22/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import Foundation

struct LyricsService {
    func execute(artist:String, song:String, completion:(results:Lyric?, error:NSError?) -> Void)   {
        let url = "http://lyrics.wikia.com/api.php?func=getSong&artist=\(artist.stringByReplacingOccurrencesOfString(" ", withString: ""))&song=\(song.stringByReplacingOccurrencesOfString(" ", withString: ""))&fmt=json"
        MainService().get(NSURL(string: url), sucess: { (data:NSData?, response:NSURLResponse?) -> Void in
            if let data = data {
                let resultsDictionary = try? NSJSONSerialization.JSONObjectWithData(data, options:.AllowFragments) as! NSDictionary
                if let resultsDictionary = resultsDictionary  {
                    if let song:[String:String] = resultsDictionary["song"] as? [String:String]
                    {
                        let lyric:Lyric = Lyric(artist:song["artist"] , song: song["song"], lyrics: song["lyrics"], url: song["url"])
                        completion(results: lyric, error: nil)
                    }
                }
            }
            }, failure: { (response:NSURLResponse?, error:NSError?) -> Void in
                print("data")
                completion(results:nil, error: error)

        })
    }
    
}