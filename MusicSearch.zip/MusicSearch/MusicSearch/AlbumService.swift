//
//  AlbumService.swift
//  MusicSearch
//
//  Created by SureshDokula on 22/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import Foundation

struct AlbumService {
    
    func execute(artist:String, completion:(results:[Track], error:NSError?) -> Void)   {
        let url = "https://itunes.apple.com/search?term="+artist.stringByReplacingOccurrencesOfString(" ", withString: "")
        MainService().get(NSURL(string:url), sucess: { (data:NSData?, response:NSURLResponse?) -> Void in
            if let data = data {
                let resultsDictionary = try? NSJSONSerialization.JSONObjectWithData(data, options:NSJSONReadingOptions(rawValue: 0)) as? NSDictionary
                if let resultsDictionary = resultsDictionary {
                    if let results:[[String:AnyObject]] = resultsDictionary!["results"] as? [[String:AnyObject]]
                    {
                        let resultsArray:[Track] = results.map({  Track(wrappertype: $0["wrapperType"] as? String, kind: $0["kind"] as? String, artistName:  $0["artistName"] as? String, collectionName:  $0["collectionName"] as? String, trackName:  $0["trackName"] as? String, trackViewUrl:  $0["trackViewUrl"] as? String, previewUrl:  $0["previewUrl"] as? String, artworkUrl30:  $0["artworkUrl30"] as? String, artworkUrl60:  $0["artworkUrl60"] as? String, artworkUrl100:  $0["artworkUrl100"] as? String, trackPrice:  $0["trackPrice"] as? NSNumber ?? 0.0, longDescription:  $0["longDescription"] as? String, primaryGenreName:  $0["primaryGenreName"] as? String)
                        })
                        return completion(results:resultsArray, error:nil)
                        }
                    }
                }
            }, failure: { (response:NSURLResponse?, error:NSError?) -> Void in
            print(error)
                return completion(results:[], error:error)
        })
    }
    
}