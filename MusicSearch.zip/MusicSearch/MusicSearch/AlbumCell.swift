//
//  AlbumCell.swift
//  MusicSearch
//
//  Created by SureshDokula on 22/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import UIKit

class AlbumCell : UITableViewCell {
    @IBOutlet  var albumImageView:UIImageView!
    @IBOutlet  var lblArtistName:UILabel!
    @IBOutlet  var lblAlbumName:UILabel!
    @IBOutlet  var lblTrackName:UILabel!
    
}