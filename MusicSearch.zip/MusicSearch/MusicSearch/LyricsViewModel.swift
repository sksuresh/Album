//
//  LyricsViewModel.swift
//  MusicSearch
//
//  Created by SureshDokula on 23/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import Foundation

enum LyricsServiceStateChange {
    case initialise
    case startProcess
    case sucess(Lyric)
    case fail(String)
}

protocol LyricsViewModelState {
    func update(state:LyricsServiceStateChange)
}

class LyricsViewModel {
    
    private let delegate:LyricsViewModelState
    
    init(delegate:LyricsViewModelState){
        self.delegate = delegate
        self.state = .initialise
    }
    
    private var state:LyricsServiceStateChange {
        didSet{
            self.delegate.update(self.state)
        }
    }
    
    func getSongForArtist(artist:String?, song:String?){
        self.state = .startProcess
        if let artist = artist, song = song {
            LyricsService().execute(artist, song:song, completion: {(results:Lyric?, error:NSError?) in
                if error != nil {
                    self.state = .fail(error!.localizedDescription)
                } else {
                    self.state = .sucess(results!)
                }
            })
        }
    }

    
}