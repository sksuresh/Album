//
//  MainService.swift
//  MusicSearch
//
//  Created by SureshDokula on 22/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import Foundation

class MainService {
    
    func get(url:NSURL?, sucess:(NSData?,NSURLResponse?) -> Void, failure:(NSURLResponse?,NSError?) -> Void) {
        let urlsession = NSURLSessionConfiguration.defaultSessionConfiguration()
        urlsession.timeoutIntervalForRequest = 30.0
        urlsession.timeoutIntervalForResource = 10.0
        let session = NSURLSession(configuration: urlsession)
        let url = url ?? NSURL()
        let dataTask =   session.dataTaskWithURL(url, completionHandler:{ (data:NSData?, response:NSURLResponse?, error:NSError?) in
        if error != nil {
        failure(response, error)
    }else{
        sucess(data, response)
        }
        })
        dataTask.resume()
    }
}