//
//  ViewModel.swift
//  MusicSearch
//
//  Created by SureshDokula on 22/10/16.
//  Copyright © 2016 Virtusa. All rights reserved.
//

import Foundation

enum StateChange {
    case initialise
    case startProcess
    case sucess([Track])
    case fail(String)
}

protocol AlbumViewModelState {
    func update(state:StateChange)
}

class AlbumViewModel {
    
    private let delegate:AlbumViewModelState
    
    init(delegate:AlbumViewModelState){
        self.delegate = delegate
        self.state = .initialise
    }
    
    private var state:StateChange {
        didSet{
            self.delegate.update(self.state)
        }
    }
    
    func getAlbumForArtist(artist:String?){
        self.state = .startProcess
        if let artist = artist {
            AlbumService().execute(artist,completion: {(results:[Track],error:NSError?) in
                if error != nil {
                    self.state = .fail(error!.localizedDescription)
                } else {
                    self.state = .sucess(results)
                }
            })
        }
    }
}